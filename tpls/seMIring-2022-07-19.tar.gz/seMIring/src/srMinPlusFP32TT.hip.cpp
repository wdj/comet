
#include "srMinPlusFP32TT.h"
#include <hip/hip_runtime.h>

#define TRANS_A 1
#define TRANS_B 1
#define KERNEL_NAME srMinPlusFP32TTKernel
#include "srMinPlusFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusFP32TTKernelBounds
#include "srMinPlusFP32.inc"
#undef KERNEL_NAME
