
#include <cassert>
#include <hip/hip_runtime.h>
#include <hiprand.h>
#include "../include/semiring.h"

//==============================================================================
void srPlusMinNN(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

void srPlusMinNT(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

void srPlusMinTN(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

void srPlusMinTT(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

//------------------------------------------------------------------------------
void srMinPlusNN(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

void srMinPlusNT(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

void srMinPlusTN(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

void srMinPlusTT(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream) { assert(false); }

//------------------------------------------------------------------------------
template <typename T>
void srMinPlusNNHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] = std::min(a[lda*l+i]+b[ldb*j+l], c[ldc*j+i]);
}

//------------------------------------------------------------------------------
template <typename T>
void srMinPlusNTHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] = std::min(a[lda*l+i]+b[ldb*l+j], c[ldc*j+i]);
}

//------------------------------------------------------------------------------
template <typename T>
void srMinPlusTNHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] = std::min(a[lda*i+l]+b[ldb*j+l], c[ldc*j+i]);
}

//------------------------------------------------------------------------------
template <typename T>
void srMinPlusTTHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] = std::min(a[lda*i+l]+b[ldb*l+j], c[ldc*j+i]);
}

//==============================================================================
template <typename T>
void srPlusMinNNHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] += std::min(a[lda*l+i], b[ldb*j+l]);
}

//------------------------------------------------------------------------------
template <typename T>
void srPlusMinNTHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] += std::min(a[lda*l+i], b[ldb*l+j]);
}

//------------------------------------------------------------------------------
template <typename T>
void srPlusMinTNHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] += std::min(a[lda*i+l], b[ldb*j+l]);
}

//------------------------------------------------------------------------------
template <typename T>
void srPlusMinTTHost(int m, int n, int k,
                     T* a, std::size_t lda,
                     T* b, std::size_t ldb,
                     T* c, std::size_t ldc)
{
    #pragma omp parallel for
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < m; ++i)
            for (int l = 0; l < k; ++l)
                c[ldc*j+i] += std::min(a[lda*i+l], b[ldb*l+j]);
}

//------------------------------------------------------------------------------
template <typename T>
void print_diff(int m, int n, T* a, int lda, T* b, int ldb)
{
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < m; ++i) {
            printf("%c", a[j*lda+i] == b[j*ldb+i] ? '.' : '#');
        }
        printf("\n");
    }
}

//==============================================================================
#define HIP_CALL(call) assert(call == hipSuccess)
#define HIPRAND_CALL(call) assert(call == HIPRAND_STATUS_SUCCESS)

//------------------------------------------------------------------------------
void generateUniform(hiprandGenerator_t generator, _Float16* a, std::size_t len)
{
    HIPRAND_CALL(hiprandGenerateUniformHalf(generator, (__half*)a, len));
}

//------------------------------------------------------------------------------
void generateUniform(hiprandGenerator_t generator, float* a, std::size_t len)
{
    HIPRAND_CALL(hiprandGenerateUniform(generator, a, len));
}

//------------------------------------------------------------------------------
void generateUniform(hiprandGenerator_t generator, double* a, std::size_t len)
{
    HIPRAND_CALL(hiprandGenerateUniformDouble(generator, a, len));
}

//------------------------------------------------------------------------------
template <typename T>
void call_on_host(int m, int n, int k,
                  T* h_a, std::size_t lda,
                  T* h_b, std::size_t ldb,
                  T* h_c, std::size_t ldc,
                  bool trans_a, bool trans_b,
                  bool plus_min)
{
    if (plus_min) {
        if (!trans_a && !trans_b) {
            srPlusMinNNHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
        else if (!trans_a && trans_b) {
            srPlusMinNTHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
        else if (trans_a && !trans_b) {
            srPlusMinTNHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
        else if (trans_a && trans_b) {
            srPlusMinTTHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
    }
    else {
        if (!trans_a && !trans_b) {
            srMinPlusNNHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
        else if (!trans_a && trans_b) {
            srMinPlusNTHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
        else if (trans_a && !trans_b) {
            srMinPlusTNHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
        else if (trans_a && trans_b) {
            srMinPlusTTHost(m, n, k,
                            h_a, lda,
                            h_b, ldb,
                            h_c, ldc);
        }
    }
}

//------------------------------------------------------------------------------
template <typename T>
void call_on_device(int m, int n, int k,
                    T* d_a, std::size_t lda,
                    T* d_b, std::size_t ldb,
                    T* d_c, std::size_t ldc,
                    bool trans_a, bool trans_b,
                    bool plus_min,
                    hipStream_t stream)
{
    if (plus_min) {
        if (!trans_a && !trans_b) {
            srPlusMinNN(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
        else if (!trans_a && trans_b) {
            srPlusMinNT(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
        else if (trans_a && !trans_b) {
            srPlusMinTN(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
        else if (trans_a && trans_b) {
            srPlusMinTT(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
    }
    else {
        if (!trans_a && !trans_b) {
            srMinPlusNN(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
        else if (!trans_a && trans_b) {
            srMinPlusNT(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
        else if (trans_a && !trans_b) {
            srMinPlusTN(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
        else if (trans_a && trans_b) {
            srMinPlusTT(m, n, k,
                        d_a, lda,
                        d_b, ldb,
                        d_c, ldc,
                        stream);
        }
    }
}

//------------------------------------------------------------------------------
template <typename T>
void run(int m, int n, int k,
         int lda, int ldb, int ldc,
         bool trans_a, bool trans_b,
         bool plus_min, bool test)
{
    // Allocate memory.
    std::size_t len_a = std::size_t(lda)*(trans_a == false ? k : m);
    std::size_t len_b = std::size_t(ldb)*(trans_b == false ? n : k);
    std::size_t len_c = std::size_t(ldc)*n;
    std::size_t size_a = len_a*sizeof(T);
    std::size_t size_b = len_b*sizeof(T);
    std::size_t size_c = len_c*sizeof(T);
    T* d_a;
    T* d_b;
    T* d_c;
    HIP_CALL(hipMalloc(&d_a, size_a));
    HIP_CALL(hipMalloc(&d_b, size_b));
    HIP_CALL(hipMalloc(&d_c, size_c));
    T* h_a;
    T* h_b;
    T* h_c;
    T* h_d;
    assert((h_a = (T*)malloc(size_a)) != nullptr);
    assert((h_b = (T*)malloc(size_b)) != nullptr);
    assert((h_c = (T*)malloc(size_c)) != nullptr);
    assert((h_d = (T*)malloc(size_c)) != nullptr);

    // Initialize libs.
    hipStream_t stream;
    HIP_CALL(hipStreamCreate(&stream));
    hiprandGenerator_t generator;
    HIPRAND_CALL(hiprandCreateGenerator(
        &generator, HIPRAND_RNG_PSEUDO_DEFAULT));
    HIPRAND_CALL(hiprandSetStream(generator, stream));

    // Initialize arrays.
    generateUniform(generator, d_a, len_a);
    generateUniform(generator, d_b, len_b);
    generateUniform(generator, d_c, len_c);
    HIP_CALL(hipMemcpy(h_a, d_a, size_a, hipMemcpyDeviceToHost));
    HIP_CALL(hipMemcpy(h_b, d_b, size_b, hipMemcpyDeviceToHost));
    HIP_CALL(hipMemcpy(h_c, d_c, size_c, hipMemcpyDeviceToHost));

    if (test == false)
        goto no_test;

    call_on_host(m, n, k,
                 h_a, lda,
                 h_b, ldb,
                 h_c, ldc,
                 trans_a, trans_b,
                 plus_min);

    call_on_device(m, n, k,
                   d_a, lda,
                   d_b, ldb,
                   d_c, ldc,
                   trans_a, trans_b,
                   plus_min,
                   stream);

no_test:
    // Copy to host and print error.
    HIP_CALL(hipDeviceSynchronize());
    HIP_CALL(hipMemcpy(h_d, d_c, size_c, hipMemcpyDeviceToHost));
    double max_error = 0.0;
    for (std::size_t i = 0; i < len_c; ++i) {
        double error = std::abs(double(h_c[i])-double(h_d[i]));
        if (error > max_error)
            max_error = error;
    }
    printf("\t%.4e\n", max_error);
    printf("\n");

    // Time on device.
    for (int i = 0; i < 5; ++i) {
        auto start = std::chrono::high_resolution_clock::now();
        call_on_device(m, n, k,
                       d_a, lda,
                       d_b, ldb,
                       d_c, ldc,
                       trans_a, trans_b,
                       plus_min,
                       stream);
        HIP_CALL(hipDeviceSynchronize());
        float usec = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::high_resolution_clock::now()-start).count();
        float sec = usec/1e6;
        float ops = 2.0*m*n*k;
        float tflops = ops/sec/1e12;
        printf("\t%.4f\n", tflops);
    }
    printf("\n");
}

//------------------------------------------------------------------------------
int main(int argc, char** argv)
{
    // Read settings.
    assert(argc >= 7);
    int m = std::atoi(argv[1]);
    int n = std::atoi(argv[2]);
    int k = std::atoi(argv[3]);
    int lda = std::atoi(argv[4]);
    int ldb = std::atoi(argv[5]);
    int ldc = std::atoi(argv[6]);
    bool plus_min = false;
    bool trans_a = false;
    bool trans_b = false;
    bool dble = false;
    bool half = false;
    bool test = false;
    int arg = 7;
    while (arg < argc) {
        std::string str(argv[arg]);
        if (str.find("plus_min") != std::string::npos) plus_min = true;
        if (str.find("trans_a") != std::string::npos) trans_a = true;
        if (str.find("trans_b") != std::string::npos) trans_b = true;
        if (str.find("double") != std::string::npos) dble = true;
        if (str.find("half") != std::string::npos) half = true;
        if (str.find("test") != std::string::npos) test = true;
        ++arg;
    }

    // Print settings.
    printf("\n");
    printf("\tM = %d\n", m);
    printf("\tN = %d\n", n);
    printf("\tK = %d\n", k);
    printf("\n");
    printf("\tLDA = %d\n", lda);
    printf("\tLDB = %d\n", ldb);
    printf("\tLDC = %d\n", ldc);
    printf("\n");
    printf("\tA: %s\n", trans_a ? "Trans" : "NoTrans");
    printf("\tB: %s\n", trans_b ? "Trans" : "NoTrans");
    printf("\n");
    printf("\toperation: %s\n", plus_min ? "PlusMin" : "MinPlus");
    printf("\tprecision: %s\n", half ? "half" : dble ? "double" : "single");
    printf("\n");
    printf("\t%s\n", test ? "testing" : "NOT testing");
    printf("\n");

    if (dble)
        run<double>(m, n, k, lda, ldb, ldc, trans_a, trans_b, plus_min, test);
    else if (half)
        run<_Float16>(m, n, k, lda, ldb, ldc, trans_a, trans_b, plus_min, test);
    else
        run<float>(m, n, k, lda, ldb, ldc, trans_a, trans_b, plus_min, test);
}
