
#include "../include/semiring.h"

//------------------------------------------------------------------------------
void srMinPlusNN(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP16NN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srMinPlusNT(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP16NT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srMinPlusTN(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP16TN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srMinPlusTT(int m, int n, int k,
                 _Float16 const* d_a, std::size_t lda,
                 _Float16 const* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP16TT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

//------------------------------------------------------------------------------
void srMinPlusNN(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP32NN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srMinPlusNT(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP32NT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srMinPlusTN(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP32TN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srMinPlusTT(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srMinPlusFP32TT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

//------------------------------------------------------------------------------
void srPlusMinNN(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP32NN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srPlusMinNT(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP32NT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srPlusMinTN(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP32TN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srPlusMinTT(int m, int n, int k,
                 float const* d_a, std::size_t lda,
                 float const* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP32TT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

//------------------------------------------------------------------------------
void srPlusMinNN(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP64NN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srPlusMinNT(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP64NT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srPlusMinTN(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP64TN(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}

void srPlusMinTT(int m, int n, int k,
                 double const* d_a, std::size_t lda,
                 double const* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream)
{
    srPlusMinFP64TT(m, n, k, d_a, lda, d_b, ldb, d_c, ldc, stream);
}
