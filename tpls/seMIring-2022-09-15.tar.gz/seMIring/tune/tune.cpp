 
#include "../../bonsai/engine/bonsai_Sweep.h"

#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <map>

#include <hip/hip_runtime.h>
#include <hipblas.h>
#include <hiprand.h>
#include <omp.h>

//------------------------------------------------------------------------------
///< struct for passing params between callbacks
template <typename T>
struct CallbackData {
    bool trans_a;
    bool trans_b;
    int m;
    int n;
    int k;
    float alpha;
    float* d_a;
    std::size_t lda;
    float* d_b;
    std::size_t ldb;
    float beta;
    float* d_c;
    std::size_t ldc;
    float* d_c_ref;               ///< reference C for correctness testing
    std::size_t len_c;            ///< number of elements in C
    hipblasHandle_t handle;       ///< hipBLAS handle
    hiprandGenerator_t generator; ///< hipRAND generator
};

//------------------------------------------------------------------------------
///< struct for passing params to the kernel
template <typename T>
struct KernelData {
    int m;
    int n;
    int k;
    float *d_a;
    std::size_t lda;
    float *d_b;
    std::size_t ldb;
    float *d_c;
    std::size_t ldc;
};

//------------------------------------------------------------------------------
int g_dim;      ///< problem size
bool g_trans_a; ///< A transposed?
bool g_trans_b; ///< B transposed?

//------------------------------------------------------------------------------
int generateUniform(hiprandGenerator_t generator, __half* a, std::size_t len)
{
    return hiprandGenerateUniformHalf(generator, a, len);
}

//------------------------------------------------------------------------------
int generateUniform(hiprandGenerator_t generator, float* a, std::size_t len)
{
    return hiprandGenerateUniform(generator, a, len);
}

//------------------------------------------------------------------------------
/// \brief
///
template <typename T>
bool init(void* callback_data,
          bonsai::KernelParams& kernel_params,
          hipStream_t stream)
{
    CallbackData<T>* cd = (CallbackData<T>*)callback_data;

    cd->trans_a = g_trans_a;
    cd->trans_b = g_trans_b;

    cd->m = g_dim;
    cd->n = g_dim;
    cd->k = g_dim;

    cd->alpha = 1.0f;
    cd->beta  = 1.0f;

    int64_t blk_m = kernel_params.at(std::string("BLK_M")).integer;
    int64_t blk_n = kernel_params.at(std::string("BLK_N")).integer;
    int64_t blk_k = kernel_params.at(std::string("BLK_K")).integer;

    // Round up dimensions.
    if (cd->m% blk_m    != 0) cd->m = (cd->m/ blk_m+1)*   blk_m;
    if (cd->n% blk_n    != 0) cd->n = (cd->n/ blk_n+1)*   blk_n;
    if (cd->k%(blk_k*2) != 0) cd->k = (cd->k/(blk_k*2)+1)*(blk_k*2);

    cd->lda = !cd->trans_a ? cd->m : cd->k;
    cd->ldb = !cd->trans_b ? cd->k : cd->n;
    cd->ldc = cd->m;

    // Compute sizes.
    std::size_t len_a = cd->m*cd->k;
    std::size_t len_b = cd->k*cd->n;
    std::size_t len_c = cd->m*cd->n;
    cd->len_c = len_c;

    std::size_t size_A = sizeof(float)*len_a;
    std::size_t size_B = sizeof(float)*len_b;
    std::size_t size_C = sizeof(float)*len_c;

    // Allocate arrays.
    int status = 0;
    status |= hipMalloc(&cd->d_a, size_A);
    status |= hipMalloc(&cd->d_b, size_B);
    status |= hipMalloc(&cd->d_c, size_C);
    status |= hipMalloc(&cd->d_c_ref, size_C);

    // Init hipBLAS handle.
    status |= hipblasCreate(&cd->handle);
    status |= hipblasSetStream(cd->handle, stream);

    // Init hipRAND generator.
    status |= hiprandCreateGenerator(
        &cd->generator, HIPRAND_RNG_PSEUDO_DEFAULT);
    status |= hiprandSetStream(cd->generator, stream);

    // Initialize arrays.
    status |= generateUniform(cd->generator, cd->d_a, len_a);
    status |= generateUniform(cd->generator, cd->d_b, len_b);
    status |= generateUniform(cd->generator, cd->d_c, len_c);
    status |= hipMemcpy(cd->d_c_ref, cd->d_c, size_C, hipMemcpyDeviceToDevice);

    return (status == 0);
}

//------------------------------------------------------------------------------
/// \brief
///
template <typename T>
bool launch(void* callback_data,
            bonsai::KernelParams& kernel_params,
            hipStream_t stream,
            hipFunction_t kernel_func)
{
    CallbackData<T>* cd = (CallbackData<T>*)callback_data;
    KernelData<T> kd = {
        cd->m,
        cd->n,
        cd->k,
        cd->d_a,
        cd->lda,
        cd->d_b,
        cd->ldb,
        cd->d_c,
        cd->ldc
    };

    int64_t blk_m = kernel_params.at(std::string("BLK_M")).integer;
    int64_t blk_n = kernel_params.at(std::string("BLK_N")).integer;
    int64_t m = cd->m;
    int64_t n = cd->n;

    assert(m%blk_m == 0);
    assert(n%blk_n == 0);

    unsigned int grid_dim_x = m/blk_m;
    unsigned int grid_dim_y = n/blk_n;
    unsigned int grid_dim_z = 1;

    unsigned int block_dim_x = kernel_params.at(std::string("DIM_M")).integer;
    unsigned int block_dim_y = kernel_params.at(std::string("DIM_N")).integer;
    unsigned int block_dim_z = 1;

    std::size_t size = sizeof(KernelData<T>);
    void *config[] = {
      HIP_LAUNCH_PARAM_BUFFER_POINTER, &kd,
      HIP_LAUNCH_PARAM_BUFFER_SIZE, &size,
      HIP_LAUNCH_PARAM_END
    };
    int status = 0;
    status |= hipModuleLaunchKernel(
        kernel_func,
        grid_dim_x, grid_dim_y, grid_dim_z,
        block_dim_x, block_dim_y, block_dim_z,
        0, stream,
        nullptr, (void**)&config);

    return (status == 0);
}

//------------------------------------------------------------------------------
/// \brief
///
template <typename T>
bool cleanup(void* callback_data,
             bonsai::KernelParams& kernel_params,
             hipStream_t stream)
{
    CallbackData<T>* cd = (CallbackData<T>*)callback_data;

    // Compure the Gflops rate.
    double elapsed = kernel_params.at(std::string("Time")).real;
    double gflops = 2.0*cd->m*cd->n*cd->k/elapsed/1e9;
    kernel_params[std::string("Gflops")].real = gflops;

    // Free arrays.
    int status = 0;
    status |= hipFree(cd->d_a);
    status |= hipFree(cd->d_b);
    status |= hipFree(cd->d_c);
    status |= hipFree(cd->d_c_ref);

    // Destroy handle and generator.
    status |= hipblasDestroy(cd->handle);
    status |= hiprandDestroyGenerator(cd->generator);

    return (status == 0);
}

//------------------------------------------------------------------------------
/// \brief
///
template <typename T>
void run(int num_reps,
         int chunk_size,
         std::string name_prec,
         std::string name_prec_trans,
         std::string option)
{
    try {
        using namespace bonsai;
        using Target = Callback::Target;
        using Type   = Callback::Type;
        // using Marker = Callback::Marker;

        // Create the sweep.
        std::string kernel_source_file_name;
        kernel_source_file_name += "../src/";
        kernel_source_file_name += name_prec;
        kernel_source_file_name += ".inc";
        Sweep sweep(
            name_prec_trans+".in.csv",  // input CSV filename
            name_prec_trans+".out.csv", // output CSV filename
            kernel_source_file_name,    // kernel source file name
            std::string("KERNEL_NAME"), // kernel function name
            sizeof(CallbackData<T>),    // size of callback data
            num_reps,                   // number of repetitions
            chunk_size,                 // dispatch chunk size
            option);                    // extra compilation options

        // Add the Gflops parameter to the output.
        sweep.addParameter(std::string("Gflops"), Value::Type::Real);

        // Create pipeline.
        sweep.addCallback(init<T>,    Target::Device               );
        sweep.addCallback(launch<T>,  Target::Device, Type::Kernel );
        sweep.addCallback(cleanup<T>, Target::Device, Type::Cleanup);

        // Run the sweep.
        sweep.run();
    }
    catch (bonsai::Exception& e) {
        std::cerr << std::endl << e.what() << std::endl << std::endl;
    }
}

//------------------------------------------------------------------------------
/// \brief
///
int main(int argc, char *argv[])
{
    assert(argc >= 4);
    g_dim = atoi(argv[1]);
    int num_reps = atoi(argv[2]);
    int chunk_size = atoi(argv[3]);

    g_trans_a = false;
    g_trans_b = false;
    bool half = false;

    int arg = 4;
    while (arg < argc) {
        std::string str(argv[arg]);
        if (str == "trans_a") g_trans_a = true;
        if (str == "trans_b") g_trans_b = true;
        if (str == "half"   ) half      = true;
        ++arg;
    }

    std::string name_prec("srMinPlus");
    if (half) name_prec += std::string("FP16");
    else      name_prec += std::string("FP32");

    std::string name_prec_trans(name_prec);
    if (!g_trans_a && !g_trans_b) name_prec_trans += std::string("NN");
    if ( g_trans_a && !g_trans_b) name_prec_trans += std::string("TN");
    if (!g_trans_a &&  g_trans_b) name_prec_trans += std::string("NT");
    if ( g_trans_a &&  g_trans_b) name_prec_trans += std::string("TT");

    std::string option;
    if (!g_trans_a && !g_trans_b) option = std::string("");
    if ( g_trans_a && !g_trans_b) option = std::string("-DTRANS_A=1");
    if (!g_trans_a &&  g_trans_b) option = std::string("-DTRANS_B=1");
    if ( g_trans_a &&  g_trans_b) option = std::string("-DTRANS_A=1 -DTRANS_B=1");

    if (half)
        run<__half>(num_reps, chunk_size, name_prec, name_prec_trans, option);
    else
        run<float>(num_reps, chunk_size, name_prec, name_prec_trans, option);
}
