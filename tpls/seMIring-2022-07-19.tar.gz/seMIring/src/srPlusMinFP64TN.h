
#define BLK_M   128
#define BLK_N   128
#define BLK_K     4
#define DIM_M     4
#define DIM_N    64
#define DIM_M_A   4
#define DIM_N_A  64
#define DIM_M_B   4
#define DIM_N_B  64

extern "C"
__global__
void srPlusMinFP64TNKernel(int m, int n, int k,
                           double *d_a, std::size_t lda,
                           double *d_b, std::size_t ldb,
                           double *d_c, std::size_t ldc);
extern "C"
__global__
void srPlusMinFP64TNKernelBounds(int m, int n, int k,
                                 double *d_a, std::size_t lda,
                                 double *d_b, std::size_t ldb,
                                 double *d_c, std::size_t ldc);
