
#define BLK_M    64
#define BLK_N   128
#define BLK_K     4
#define DIM_M     8
#define DIM_N    32
#define DIM_M_A  64
#define DIM_N_A   4
#define DIM_M_B   4
#define DIM_N_B  64

extern "C"
__global__
void srPlusMinFP32NNKernel(int m, int n, int k,
                           float const* d_a, std::size_t lda,
                           float const* d_b, std::size_t ldb,
                           float* d_c, std::size_t ldc);
extern "C"
__global__
void srPlusMinFP32NNKernelBounds(int m, int n, int k,
                                 float const* d_a, std::size_t lda,
                                 float const* d_b, std::size_t ldb,
                                 float* d_c, std::size_t ldc);
