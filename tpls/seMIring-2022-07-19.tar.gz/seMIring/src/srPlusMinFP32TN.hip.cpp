
#include "srPlusMinFP32TN.h"
#include <hip/hip_runtime.h>

#define TRANS_A 1
#define KERNEL_NAME srPlusMinFP32TNKernel
#include "srPlusMinFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srPlusMinFP32TNKernelBounds
#include "srPlusMinFP32.inc"
#undef KERNEL_NAME
