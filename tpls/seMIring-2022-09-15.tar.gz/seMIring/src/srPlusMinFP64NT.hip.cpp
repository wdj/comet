
#include "srPlusMinFP64NT.h"
#include <hip/hip_runtime.h>

#define TRANS_B 1
#define KERNEL_NAME srPlusMinFP64NTKernel
#include "srPlusMinFP64.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srPlusMinFP64NTKernelBounds
#include "srPlusMinFP64.inc"
#undef KERNEL_NAME
