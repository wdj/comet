
#include "srMinPlusFP16NT.h"
#include <hip/hip_runtime.h>

#define TRANS_B 1
#define KERNEL_NAME srMinPlusFP16NTKernel
#include "srMinPlusFP16.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusFP16NTKernelBounds
#include "srMinPlusFP16.inc"
#undef KERNEL_NAME
