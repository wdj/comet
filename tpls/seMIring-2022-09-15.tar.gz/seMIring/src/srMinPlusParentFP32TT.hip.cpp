
#include "srMinPlusParentFP32TT.h"
#include <hip/hip_runtime.h>

#define TRANS_A 1
#define TRANS_B 1
#define KERNEL_NAME srMinPlusParentFP32TTKernel
#include "srMinPlusParentFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusParentFP32TTKernelBounds
#include "srMinPlusParentFP32.inc"
#undef KERNEL_NAME
