
#include "srMinPlusParentFP32NN.h"
#include <hip/hip_runtime.h>

#define KERNEL_NAME srMinPlusParentFP32NNKernel
#include "srMinPlusParentFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusParentFP32NNKernelBounds
#include "srMinPlusParentFP32.inc"
#undef KERNEL_NAME
