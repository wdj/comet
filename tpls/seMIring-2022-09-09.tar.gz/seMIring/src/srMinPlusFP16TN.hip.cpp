
#include "srMinPlusFP16TN.h"
#include <hip/hip_runtime.h>

#define TRANS_A 1
#define KERNEL_NAME srMinPlusFP16TNKernel
#include "srMinPlusFP16.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusFP16TNKernelBounds
#include "srMinPlusFP16.inc"
#undef KERNEL_NAME
