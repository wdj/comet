
#include "srMinPlusFP16NN.h"
#include <hip/hip_runtime.h>

#define KERNEL_NAME srMinPlusFP16NNKernel
#include "srMinPlusFP16.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusFP16NNKernelBounds
#include "srMinPlusFP16.inc"
#undef KERNEL_NAME
