//-----------------------------------------------------------------------------
/*!
 * \file   mpi.h
 * \author Wayne Joubert
 * \date   Mon Jun  1 10:30:41 EDT 2020
 * \brief  MPI stub library, declarations.
 */
//-----------------------------------------------------------------------------

#ifndef _comet_mpi_stub_h_
#define _comet_mpi_stub_h_

#include <stdlib.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

//-----------------------------------------------------------------------------

#define MPI_MAX_PROCESSOR_NAME 1

int MPI_Get_processor_name(char* name, int* len);

//-----------------------------------------------------------------------------
/// \brief Error handling.

//typedef int COMET_MPI_Error_t;

#define MPI_SUCCESS 0

//-----------------------------------------------------------------------------
/// \brief Data types.

typedef size_t MPI_Datatype;

const MPI_Datatype MPI_BYTE = sizeof(char);
const MPI_Datatype MPI_CHAR = sizeof(char);
const MPI_Datatype MPI_SHORT = sizeof(signed short int);
const MPI_Datatype MPI_INT = sizeof(signed int);
const MPI_Datatype MPI_LONG = sizeof(signed long int);
const MPI_Datatype MPI_LONG_LONG_INT = sizeof(signed long long int);
const MPI_Datatype MPI_LONG_LONG = sizeof(signed long long int);
const MPI_Datatype MPI_SIGNED_CHAR = sizeof(signed char);
const MPI_Datatype MPI_UNSIGNED_CHAR = sizeof(unsigned char);
const MPI_Datatype MPI_UNSIGNED_SHORT = sizeof(unsigned short int);
const MPI_Datatype MPI_UNSIGNED = sizeof(unsigned int);
const MPI_Datatype MPI_UNSIGNED_LONG = sizeof(unsigned long int);
const MPI_Datatype MPI_UNSIGNED_LONG_LONG = sizeof(unsigned long long int);
const MPI_Datatype MPI_FLOAT = sizeof(float);
const MPI_Datatype MPI_DOUBLE = sizeof(double);
const MPI_Datatype MPI_LONG_DOUBLE = sizeof(long double);
const MPI_Datatype MPI_WCHAR = sizeof(wchar_t);
const MPI_Datatype MPI_DOUBLE_COMPLEX = 2*sizeof(double);

//-----------------------------------------------------------------------------
/// \brief Initialize/finalize.

int MPI_Init(int *argc, char ***argv);
int MPI_Finalize();

//-----------------------------------------------------------------------------
/// \brief Communicators.

typedef int MPI_Comm;
#define MPI_COMM_WORLD ((MPI_Comm)101)
#define MPI_COMM_SELF  ((MPI_Comm)102)
#define MPI_COMM_NULL  ((MPI_Comm)0)

int MPI_Comm_rank(MPI_Comm comm, int *rank);
int MPI_Comm_size(MPI_Comm comm, int *size);

int MPI_Comm_split(MPI_Comm comm, int color, int key, MPI_Comm *newcomm);

int MPI_Comm_free(MPI_Comm *comm);

int MPI_Comm_dup(MPI_Comm comm, MPI_Comm *newcomm);

//-----------------------------------------------------------------------------
/// \brief Send/receive.

typedef int MPI_Request;
typedef int MPI_Status;
#define MPI_REQUEST_NULL  ((MPI_Request)0)

int MPI_Recv(void *buf, int count, MPI_Datatype datatype, int source,
             int tag, MPI_Comm comm, MPI_Status *status);

int MPI_Irecv(void *buf, int count, MPI_Datatype datatype, int source,
              int tag, MPI_Comm comm, MPI_Request *request);

int MPI_Send(const void *buf, int count, MPI_Datatype datatype, int dest,
             int tag, MPI_Comm comm);

int MPI_Issend(const void *buf, int count, MPI_Datatype datatype, int dest,
               int tag, MPI_Comm comm, MPI_Request *request);

int MPI_Isend(const void *buf, int count, MPI_Datatype datatype, int dest,
              int tag, MPI_Comm comm, MPI_Request *request);

int MPI_Sendrecv(const void *sendbuf, int sendcount, MPI_Datatype sendtype,
                 int dest, int sendtag,
                 void *recvbuf, int recvcount, MPI_Datatype recvtype,
                 int source, int recvtag,
                 MPI_Comm comm, MPI_Status *status);

int MPI_Wait(MPI_Request *request, MPI_Status *status);

int MPI_Waitall(int count, MPI_Request array_of_requests[],
                MPI_Status array_of_statuses[]);

//-----------------------------------------------------------------------------
/// \brief Collectives.

typedef int MPI_Op;
#define MPI_SUM ((MPI_Op)0)
#define MPI_MIN ((MPI_Op)0)
#define MPI_MAX ((MPI_Op)0)

int MPI_Barrier(MPI_Comm comm);

int MPI_Reduce(const void *sendbuf, void *recvbuf, int count, 
               MPI_Datatype datatype, MPI_Op op, int root, MPI_Comm comm);

int MPI_Allreduce(const void *sendbuf, void *recvbuf, int count,
                  MPI_Datatype datatype, MPI_Op op, MPI_Comm comm);

int MPI_Iallreduce(const void *sendbuf, void *recvbuf, int count,
                   MPI_Datatype datatype, MPI_Op op, MPI_Comm comm, 
                   MPI_Request *request);

int MPI_Bcast(void *buffer, int count, MPI_Datatype datatype, int root,
              MPI_Comm comm);

int MPI_Gather(const void *sendbuf, int sendcount, MPI_Datatype sendtype,
               void *recvbuf, int recvcount, MPI_Datatype recvtype, int root,
               MPI_Comm comm);

//-----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif //_comet_mpi_stub_h_

//=============================================================================
