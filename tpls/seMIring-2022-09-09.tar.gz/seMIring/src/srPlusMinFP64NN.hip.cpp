
#include "srPlusMinFP64NN.h"
#include <hip/hip_runtime.h>

#define KERNEL_NAME srPlusMinFP64NNKernel
#include "srPlusMinFP64.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srPlusMinFP64NNKernelBounds
#include "srPlusMinFP64.inc"
#undef KERNEL_NAME
