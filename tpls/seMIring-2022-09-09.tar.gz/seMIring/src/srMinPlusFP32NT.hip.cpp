
#include "srMinPlusFP32NT.h"
#include <hip/hip_runtime.h>

#define TRANS_B 1
#define KERNEL_NAME srMinPlusFP32NTKernel
#include "srMinPlusFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusFP32NTKernelBounds
#include "srMinPlusFP32.inc"
#undef KERNEL_NAME
