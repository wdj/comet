
#include "srMinPlusFP32TN.h"
#include <hip/hip_runtime.h>

#define TRANS_A 1
#define KERNEL_NAME srMinPlusFP32TNKernel
#include "srMinPlusFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srMinPlusFP32TNKernelBounds
#include "srMinPlusFP32.inc"
#undef KERNEL_NAME
