
#include <hip/hip_runtime.h>

//------------------------------------------------------------------------------
extern "C"
void srMinPlusFP16NN(int m, int n, int k,
                     _Float16* d_a, std::size_t lda,
                     _Float16* d_b, std::size_t ldb,
                     _Float16* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srMinPlusFP16NT(int m, int n, int k,
                     _Float16* d_a, std::size_t lda,
                     _Float16* d_b, std::size_t ldb,
                     _Float16* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srMinPlusFP16TN(int m, int n, int k,
                     _Float16* d_a, std::size_t lda,
                     _Float16* d_b, std::size_t ldb,
                     _Float16* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srMinPlusFP16TT(int m, int n, int k,
                     _Float16* d_a, std::size_t lda,
                     _Float16* d_b, std::size_t ldb,
                     _Float16* d_c, std::size_t ldc,
                     hipStream_t stream);

void srMinPlusNN(int m, int n, int k,
                 _Float16* d_a, std::size_t lda,
                 _Float16* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream);

void srMinPlusNT(int m, int n, int k,
                 _Float16* d_a, std::size_t lda,
                 _Float16* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream);

void srMinPlusTN(int m, int n, int k,
                 _Float16* d_a, std::size_t lda,
                 _Float16* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream);

void srMinPlusTT(int m, int n, int k,
                 _Float16* d_a, std::size_t lda,
                 _Float16* d_b, std::size_t ldb,
                 _Float16* d_c, std::size_t ldc,
                 hipStream_t stream);

//------------------------------------------------------------------------------
extern "C"
void srMinPlusFP32NN(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srMinPlusFP32NT(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srMinPlusFP32TN(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srMinPlusFP32TT(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

void srMinPlusNN(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

void srMinPlusNT(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

void srMinPlusTN(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

void srMinPlusTT(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

//------------------------------------------------------------------------------
extern "C"
void srPlusMinFP32NN(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srPlusMinFP32NT(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srPlusMinFP32TN(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srPlusMinFP32TT(int m, int n, int k,
                     float* d_a, std::size_t lda,
                     float* d_b, std::size_t ldb,
                     float* d_c, std::size_t ldc,
                     hipStream_t stream);

void srPlusMinNN(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

void srPlusMinNT(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

void srPlusMinTN(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

void srPlusMinTT(int m, int n, int k,
                 float* d_a, std::size_t lda,
                 float* d_b, std::size_t ldb,
                 float* d_c, std::size_t ldc,
                 hipStream_t stream);

//------------------------------------------------------------------------------
extern "C"
void srPlusMinFP64NN(int m, int n, int k,
                     double* d_a, std::size_t lda,
                     double* d_b, std::size_t ldb,
                     double* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srPlusMinFP64NT(int m, int n, int k,
                     double* d_a, std::size_t lda,
                     double* d_b, std::size_t ldb,
                     double* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srPlusMinFP64TN(int m, int n, int k,
                     double* d_a, std::size_t lda,
                     double* d_b, std::size_t ldb,
                     double* d_c, std::size_t ldc,
                     hipStream_t stream);

extern "C"
void srPlusMinFP64TT(int m, int n, int k,
                     double* d_a, std::size_t lda,
                     double* d_b, std::size_t ldb,
                     double* d_c, std::size_t ldc,
                     hipStream_t stream);

void srPlusMinNN(int m, int n, int k,
                 double* d_a, std::size_t lda,
                 double* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream);

void srPlusMinNT(int m, int n, int k,
                 double* d_a, std::size_t lda,
                 double* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream);

void srPlusMinTN(int m, int n, int k,
                 double* d_a, std::size_t lda,
                 double* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream);

void srPlusMinTT(int m, int n, int k,
                 double* d_a, std::size_t lda,
                 double* d_b, std::size_t ldb,
                 double* d_c, std::size_t ldc,
                 hipStream_t stream);
