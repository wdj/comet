
#define BLK_M    64
#define BLK_N   128
#define BLK_K     4
#define DIM_M     8
#define DIM_N    32
#define DIM_M_A   4
#define DIM_N_A  64
#define DIM_M_B  64
#define DIM_N_B   4

extern "C"
__global__
void srPlusMinFP32TTKernel(int m, int n, int k,
                           float *d_a, std::size_t lda,
                           float *d_b, std::size_t ldb,
                           float *d_c, std::size_t ldc);
extern "C"
__global__
void srPlusMinFP32TTKernelBounds(int m, int n, int k,
                                 float *d_a, std::size_t lda,
                                 float *d_b, std::size_t ldb,
                                 float *d_c, std::size_t ldc);
