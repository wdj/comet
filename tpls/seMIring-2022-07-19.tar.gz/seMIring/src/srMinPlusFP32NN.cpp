
#include "srMinPlusFP32NN.h"
#include <hip/hip_runtime.h>

extern "C"
void srMinPlusFP32NN(
    int m, int n, int k,
    float* d_a, std::size_t lda,
    float* d_b, std::size_t ldb,
    float* d_c, std::size_t ldc,
    hipStream_t stream)
{
    if (m%BLK_M == 0 && n%BLK_N == 0 && k%(2*BLK_K) == 0) {
        dim3 group_dim(DIM_M, DIM_N);
        dim3 grid_dim(m/BLK_M, n/BLK_N);
        srMinPlusFP32NNKernel<<<grid_dim, group_dim, 0, stream>>>(
            m, n, k, d_a, lda, d_b, ldb, d_c, ldc);
    }
    else {
        dim3 group_dim(DIM_M, DIM_N);
        dim3 grid_dim(m%BLK_M == 0 ? m/BLK_M : m/BLK_M+1,
                      n%BLK_N == 0 ? n/BLK_N : n/BLK_N+1);
        srMinPlusFP32NNKernelBounds<<<grid_dim, group_dim, 0, stream>>>(
            m, n, k, d_a, lda, d_b, ldb, d_c, ldc);
    }
}
