
import sys

trans_a = False
trans_b = False

wave_size = 64
type_size = 4

for i in range(1, len(sys.argv)):
    if (sys.argv[i] == "trans_a"):
        trans_a = True
    if (sys.argv[i] == "trans_b"):
        trans_b = True
    if (sys.argv[i] == "half"):
        type_size = 2

max_threads_per_block = 1024
min_threads_per_block = 256
max_shmem_per_block = 65536

print("BLK_M,BLK_N,BLK_K,DIM_M,DIM_N,DIM_M_A,DIM_N_A,DIM_M_B,DIM_N_B")
print("Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer")
print("Compile,Compile,Compile,Compile,Compile,Compile,Compile,Compile,Compile")

for dim_m in range(4, 64+1, 4):
  for dim_n in range(4, 64+1, 4):
    threads_per_block = dim_m*dim_n

    if threads_per_block > max_threads_per_block:
      continue

    if threads_per_block < min_threads_per_block:
      continue

    if threads_per_block % wave_size != 0:
      continue

    for blk_m in range(dim_m, 256+1, dim_m):
      for blk_n in range(dim_n, 256+1, dim_n):

        for dim_m_a in range(4, blk_m+1, 4):
          for dim_n_a in range(4, 64+1, 4):

            if dim_m_a*dim_n_a != threads_per_block:
              continue

            for dim_m_b in range(4, 64+1, 4):
              for dim_n_b in range(4, blk_n+1, 4):

                if dim_m_b*dim_n_b != threads_per_block:
                  continue

                for blk_k in range(4, 64+1, 4):

                    if blk_m%dim_m_a != 0:
                      continue

                    if blk_k%dim_n_a != 0:
                      continue

                    if blk_k%dim_m_b != 0:
                      continue

                    if blk_n%dim_n_b != 0:
                      continue

                    loads_per_block = blk_m*blk_k + blk_k*blk_n
                    shmem_per_block = loads_per_block*type_size*2
                    if shmem_per_block > max_shmem_per_block:
                      continue

                    print(str(blk_m)+","+str(blk_n)+","+str(blk_k)+","+
                          str(dim_m)+","+str(dim_n), end = "")

                    if (trans_a == False):
                        print(","+str(dim_m_a)+","+str(dim_n_a), end = "")
                    else:
                        print(","+str(dim_n_a)+","+str(dim_m_a), end = "")

                    if (trans_b == False):
                        print(","+str(dim_m_b)+","+str(dim_n_b))
                    else:
                        print(","+str(dim_n_b)+","+str(dim_m_b))
