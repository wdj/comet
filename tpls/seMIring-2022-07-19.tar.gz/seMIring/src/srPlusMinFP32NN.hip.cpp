
#include "srPlusMinFP32NN.h"
#include <hip/hip_runtime.h>

#define KERNEL_NAME srPlusMinFP32NNKernel
#include "srPlusMinFP32.inc"
#undef KERNEL_NAME

#define BOUNDS 1
#define KERNEL_NAME srPlusMinFP32NNKernelBounds
#include "srPlusMinFP32.inc"
#undef KERNEL_NAME
