//-----------------------------------------------------------------------------
/*!
 * \file   mpi.c
 * \author Wayne Joubert
 * \date   Mon Jun  1 10:30:41 EDT 2020
 * \brief  MPI stub library, definitions.
 */
//-----------------------------------------------------------------------------

#include <mpi.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

//-----------------------------------------------------------------------------
/// \brief Initialize/finalize.

int MPI_Init(int *argc, char ***argv) {return 0;}
int MPI_Finalize() {return 0;}

//-----------------------------------------------------------------------------
/// \brief Communicators.

int MPI_Comm_rank(MPI_Comm comm, int *rank) {
  *rank = 0;
  return 0;}
int MPI_Comm_size(MPI_Comm comm, int *size) {
  *size = 1;
  return 0;}

int MPI_Comm_split(MPI_Comm comm, int color, int key, MPI_Comm *newcomm){
  return 0;
}

int MPI_Comm_free(MPI_Comm *comm){
  return 0;
}

int MPI_Comm_dup(MPI_Comm comm, MPI_Comm *newcomm){
  return 0;
}

//-----------------------------------------------------------------------------
/// \brief Send/receive.

int MPI_Recv(void *buf, int count, MPI_Datatype datatype, int source, 
             int tag, MPI_Comm comm, MPI_Status *status) {
  return 0;
}

int MPI_Irecv(void *buf, int count, MPI_Datatype datatype, int source,
              int tag, MPI_Comm comm, MPI_Request *request) {
  return 0;
}

int MPI_Send(const void *buf, int count, MPI_Datatype datatype, int dest, 
             int tag, MPI_Comm comm) {
  return 0;
}

int MPI_Issend(const void *buf, int count, MPI_Datatype datatype, int dest, 
               int tag, MPI_Comm comm, MPI_Request *request) {
  return 0;
}

int MPI_Isend(const void *buf, int count, MPI_Datatype datatype, int dest, 
              int tag, MPI_Comm comm, MPI_Request *request) {
  return 0;
}

int MPI_Sendrecv(const void *sendbuf, int sendcount, MPI_Datatype sendtype,
                 int dest, int sendtag,
                 void *recvbuf, int recvcount, MPI_Datatype recvtype,
                 int source, int recvtag,
                 MPI_Comm comm, MPI_Status *status) {
  return 0;
}

int MPI_Wait(MPI_Request *request, MPI_Status *status) {
  return 0;
}

int MPI_Waitall(int count, MPI_Request array_of_requests[],
                MPI_Status array_of_statuses[]) {
  return 0;
}

//-----------------------------------------------------------------------------
/// \brief Collectives.

int MPI_Barrier(MPI_Comm comm) {
  return 0;
}

int MPI_Reduce(const void *sendbuf, void *recvbuf, int count,
               MPI_Datatype datatype, MPI_Op op, int root, MPI_Comm comm) {
  memcpy(recvbuf, sendbuf, count*datatype);
  return 0;
}

int MPI_Allreduce(const void *sendbuf, void *recvbuf, int count,
                  MPI_Datatype datatype, MPI_Op op, MPI_Comm comm) {
  memcpy(recvbuf, sendbuf, count*datatype);
  return 0;
}

int MPI_Iallreduce(const void *sendbuf, void *recvbuf, int count,
                   MPI_Datatype datatype, MPI_Op op, MPI_Comm comm,
                   MPI_Request *request) {
  memcpy(recvbuf, sendbuf, count*datatype);
  return 0;
}

int MPI_Bcast(void *buffer, int count, MPI_Datatype datatype, int root,
              MPI_Comm comm) {
  return 0;
}

int MPI_Gather(const void *sendbuf, int sendcount, MPI_Datatype sendtype,
               void *recvbuf, int recvcount, MPI_Datatype recvtype, int root,
               MPI_Comm comm) {
  memcpy(recvbuf, sendbuf, sendcount*sendtype);
  return 0;
}

//-----------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

//=============================================================================
